# SW_2020_Matlab_OFDM_simulation
OFDM transmiter/receiver. Matlab simulation and modeling.
